/**
 * Cloasta — Billing & Limits UI Manager
 * 
 * Bridges the UI components with usageTracker.js.
 * Manages the upgrade modal, reset countdown timer,
 * and modal button event listeners (CSP-safe, no inline onclick).
 */

import { getUsageState, checkLimit, incrementUsage, LIMITS } from '../engine/usageTracker.js';

let resetTimerInterval = null;

async function initBillingUI() {
  try {
    await refreshUI();
    initModalButtons();
  } catch (error) {
    console.error('[BillingUI] Error during initial UI refresh:', error);
  }
}

function initModalButtons() {
  const btnNotNow = document.getElementById('btn-not-now');
  const btnUpgradePro = document.getElementById('btn-upgrade-pro');
  const btnStartCloasta = document.getElementById('btn-start-cloasta');

  if (btnNotNow) {
    btnNotNow.addEventListener('click', () => {
      window.modalDismissed = true;
      document.getElementById('upgrade-overlay').style.display = 'none';
    });
  }

  if (btnUpgradePro) {
    btnUpgradePro.addEventListener('click', () => {
      chrome.tabs.create({ url: 'https://cloasta-landingpage.vercel.app/#pricing' });
    });
  }

  if (btnStartCloasta) {
    btnStartCloasta.addEventListener('click', () => {
      chrome.storage.local.set({ cloasta_onboarded: true });
      document.getElementById('onboarding-overlay').style.display = 'none';
    });
  }
}

async function refreshUI() {
  // Update Usage Pill for Pro
  const pill = document.getElementById('usage-pill');
  const text = document.getElementById('usage-text');
  
  if (pill && text) {
    text.textContent = 'PRO UNLIMITED';
    pill.classList.remove('limit-reached');
    pill.classList.add('pro-active');
  }
}

/**
 * Updates the countdown timer text inside the upgrade modal.
 */
function showResetTime() {
  const now = new Date();
  const midnight = new Date(now);
  midnight.setHours(24, 0, 0, 0);
  const diffMs = midnight - now;
  const diffH = Math.floor(diffMs / (1000 * 60 * 60));
  const diffM = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
  const el = document.getElementById('modal-reset-time');
  if (el) {
    el.textContent = `Resets in ${diffH}h ${diffM}m`;
  }
}

/**
 * Starts a live-updating countdown that refreshes every 30 seconds.
 */
function startResetTimer() {
  stopResetTimer();
  showResetTime(); // show immediately
  resetTimerInterval = setInterval(showResetTime, 30000); // update every 30s
}

/**
 * Stops the live countdown interval.
 */
function stopResetTimer() {
  if (resetTimerInterval) {
    clearInterval(resetTimerInterval);
    resetTimerInterval = null;
  }
}

/**
 * Checks limit. If allowed, increments and returns true.
 * If not allowed, shows the upgrade modal with live countdown.
 */
async function attemptAction(actionType) {
  // Cloasta Pro: Always allowed
  await incrementUsage(actionType);
  await refreshUI();
  return true;
}

export { initBillingUI, attemptAction, refreshUI };
