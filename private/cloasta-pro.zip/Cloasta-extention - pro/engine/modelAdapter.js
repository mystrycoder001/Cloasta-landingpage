/**
 * Cloasta — Multi-Model Adapter
 * 
 * Reformats optimized prompts for each target AI model's strengths.
 * Each adapter adjusts structure, verbosity, instruction patterns, and formatting
 * while preserving all semantic content.
 */

const MODEL_PROFILES = {
  claude: {
    id: 'claude',
    label: 'Claude',
    shortLabel: 'Claude',
    color: '#d4a27f',
    description: 'Structured reasoning, XML tags, long-form context',
    features: ['Deep reasoning', 'XML structure', 'Nuanced analysis']
  },
  chatgpt: {
    id: 'chatgpt',
    label: 'ChatGPT',
    shortLabel: 'GPT',
    color: '#10a37f',
    description: 'Balanced clarity, markdown formatting, step instructions',
    features: ['Versatile', 'Markdown native', 'Custom instructions']
  },
  gemini: {
    id: 'gemini',
    label: 'Gemini',
    shortLabel: 'Gemini',
    color: '#4285f4',
    description: 'Concise framing, clear task statement, structured output',
    features: ['Concise', 'Multi-modal', 'Task-focused']
  },
  deepseek: {
    id: 'deepseek',
    label: 'DeepSeek',
    shortLabel: 'DS',
    color: '#5b6ee1',
    description: 'Technical precision, code emphasis, explicit constraints',
    features: ['Code-focused', 'Technical', 'Reasoning chains']
  },
  generic: {
    id: 'generic',
    label: 'Universal',
    shortLabel: 'Any',
    color: '#8b5cf6',
    description: 'Works well across all AI models',
    features: ['Compatible', 'Balanced', 'Standard format']
  }
};


/* ══════════════════════════════════════════════
   ADAPTERS
   ══════════════════════════════════════════════ */

/**
 * Adapt prompt for Claude
 * - Uses XML-style tags for clear context separation
 * - Encourages structured thinking
 * - Supports longer system context
 */
function adaptForClaude(prompt) {
  let adapted = '';

  // Extract sections from the markdown prompt
  const sections = parseMarkdownSections(prompt);

  // Wrap system context in XML tags
  if (sections.systemContext) {
    adapted += `<system_context>\n${sections.systemContext}\n</system_context>\n\n`;
  }

  // User profile in XML
  if (sections.userProfile) {
    adapted += `<user_profile>\n${sections.userProfile}\n</user_profile>\n\n`;
  }

  // Main task
  if (sections.objective) {
    adapted += `<task>\n${sections.objective}\n</task>\n\n`;
  }

  // Context
  if (sections.context) {
    adapted += `<context>\n${sections.context}\n</context>\n\n`;
  }

  // Constraints
  if (sections.constraints) {
    adapted += `<constraints>\n${sections.constraints}\n</constraints>\n\n`;
  }

  // Additional details
  if (sections.details) {
    adapted += `<additional_details>\n${sections.details}\n</additional_details>\n\n`;
  }

  // Output expectations
  if (sections.expectedOutput) {
    adapted += `<output_requirements>\n${sections.expectedOutput}\n\nPlease think through this step-by-step before providing your final response.\n</output_requirements>`;
  }

  // If no sections were parsed, wrap entire prompt
  if (!adapted.trim()) {
    adapted = `<task>\n${prompt}\n</task>\n\nPlease think through this carefully and provide a thorough, well-structured response.`;
  }

  return adapted.trim();
}

/**
 * Adapt prompt for ChatGPT
 * - Clean markdown formatting
 * - Clear step-by-step instructions
 * - Balanced verbosity
 */
function adaptForChatGPT(prompt) {
  let adapted = '';

  const sections = parseMarkdownSections(prompt);

  // System/role context as a preamble
  if (sections.systemContext) {
    adapted += `**Role & Context:**\n${sections.systemContext}\n\n---\n\n`;
  }

  // User profile as context
  if (sections.userProfile) {
    adapted += `**About Me:**\n${sections.userProfile}\n\n`;
  }

  // Main instruction
  if (sections.objective) {
    adapted += `**Task:**\n${sections.objective}\n\n`;
  }

  // Background
  if (sections.context) {
    adapted += `**Background:**\n${sections.context}\n\n`;
  }

  // Constraints as a numbered list
  if (sections.constraints) {
    adapted += `**Requirements:**\n${sections.constraints}\n\n`;
  }

  // Details
  if (sections.details) {
    adapted += `**Additional Details:**\n${sections.details}\n\n`;
  }

  // Output format
  if (sections.expectedOutput) {
    adapted += `**How to Respond:**\n${sections.expectedOutput}`;
  }

  if (!adapted.trim()) {
    adapted = prompt;
  }

  return adapted.trim();
}

/**
 * Adapt prompt for Gemini
 * - Concise and direct
 * - Task-first structure
 * - Minimal preamble
 */
function adaptForGemini(prompt) {
  let adapted = '';

  const sections = parseMarkdownSections(prompt);

  // Lead with the task (Gemini prefers directness)
  if (sections.objective) {
    adapted += `${sections.objective}\n\n`;
  }

  // Compact context
  if (sections.context) {
    adapted += `**Context:** ${sections.context.replace(/\n+/g, ' ').trim()}\n\n`;
  }

  // System context as brief instruction
  if (sections.systemContext) {
    adapted += `**Approach:** ${sections.systemContext.replace(/\n+/g, ' ').trim()}\n\n`;
  }

  // User profile (compact)
  if (sections.userProfile) {
    const compactProfile = sections.userProfile
      .split('\n')
      .filter(l => l.trim())
      .map(l => l.trim())
      .join(' | ');
    adapted += `**User Profile:** ${compactProfile}\n\n`;
  }

  // Constraints (inline)
  if (sections.constraints) {
    adapted += `**Constraints:**\n${sections.constraints}\n\n`;
  }

  // Output (brief)
  if (sections.expectedOutput) {
    adapted += `**Output:** ${sections.expectedOutput.replace(/\n+/g, ' ').trim()}`;
  }

  if (!adapted.trim()) {
    adapted = prompt;
  }

  return adapted.trim();
}

/**
 * Adapt prompt for DeepSeek
 * - Heavy technical precision
 * - Explicit code expectations
 * - Clear language/framework constraints
 */
function adaptForDeepSeek(prompt) {
  let adapted = '';

  const sections = parseMarkdownSections(prompt);

  // Technical context
  if (sections.systemContext) {
    adapted += `### System Instructions\n${sections.systemContext}\n\n`;
  }

  // User profile
  if (sections.userProfile) {
    adapted += `### Developer Profile\n${sections.userProfile}\n\n`;
  }

  // Task with technical framing
  if (sections.objective) {
    adapted += `### Task\n${sections.objective}\n\n`;
  }

  // Technical context
  if (sections.context) {
    adapted += `### Technical Context\n${sections.context}\n\n`;
  }

  // Constraints as explicit rules
  if (sections.constraints) {
    adapted += `### Requirements & Constraints\n${sections.constraints}\n\n`;
  }

  // Details
  if (sections.details) {
    adapted += `### Implementation Details\n${sections.details}\n\n`;
  }

  // Output expectations with code emphasis
  if (sections.expectedOutput) {
    adapted += `### Expected Output\n${sections.expectedOutput}\n\n`;
  }

  adapted += `### Instructions\n`;
  adapted += `- Provide complete, production-ready code\n`;
  adapted += `- Include error handling and edge cases\n`;
  adapted += `- Add concise inline comments for complex logic\n`;
  adapted += `- If multiple approaches exist, briefly explain the trade-offs`;

  if (!adapted.trim()) {
    adapted = prompt + '\n\nProvide complete, production-ready code with error handling.';
  }

  return adapted.trim();
}

/**
 * Generic adapter — works across all models
 */
function adaptGeneric(prompt) {
  // The prompt from the optimizer is already in a good generic format
  // Just ensure clean markdown formatting
  return prompt
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}


/* ══════════════════════════════════════════════
   SECTION PARSER
   ══════════════════════════════════════════════ */

/**
 * Parse markdown prompt into named sections
 */
function parseMarkdownSections(prompt) {
  const sections = {
    systemContext: '',
    userProfile: '',
    objective: '',
    context: '',
    constraints: '',
    details: '',
    expectedOutput: ''
  };

  // Split by ## headers
  const parts = prompt.split(/^##\s+/m);

  for (const part of parts) {
    if (!part.trim()) continue;

    const firstLine = part.split('\n')[0].toLowerCase().trim();
    const content = part.split('\n').slice(1).join('\n').trim();

    if (!content) {
      // If the whole part has no header, it might be content itself
      if (!firstLine.match(/^(system|user|objective|context|constraint|detail|expect|addition|background)/)) {
        sections.objective = sections.objective || part.trim();
      }
      continue;
    }

    if (firstLine.includes('system') || firstLine.includes('role') || firstLine.includes('preamble')) {
      sections.systemContext = content;
    } else if (firstLine.includes('user') || firstLine.includes('profile') || firstLine.includes('passport')) {
      sections.userProfile = content;
    } else if (firstLine.includes('objective') || firstLine.includes('goal') || firstLine.includes('task') ||
      firstLine.includes('learning') || firstLine.includes('creative') || firstLine.includes('technical') ||
      firstLine.includes('research question')) {
      sections.objective = content;
    } else if (firstLine.includes('context') || firstLine.includes('background') || firstLine.includes('business')) {
      sections.context = content;
    } else if (firstLine.includes('constraint') || firstLine.includes('requirement') || firstLine.includes('key metric')) {
      sections.constraints = content;
    } else if (firstLine.includes('detail') || firstLine.includes('additional') || firstLine.includes('scope')) {
      sections.details = content;
    } else if (firstLine.includes('output') || firstLine.includes('expect') || firstLine.includes('format') ||
      firstLine.includes('tone') || firstLine.includes('respond')) {
      sections.expectedOutput = (sections.expectedOutput ? sections.expectedOutput + '\n' : '') + content;
    } else {
      // Unknown section, add to details
      sections.details = (sections.details ? sections.details + '\n\n' : '') + content;
    }
  }

  return sections;
}


/* ══════════════════════════════════════════════
   MAIN ADAPTER
   ══════════════════════════════════════════════ */

/**
 * Adapt an optimized prompt for a specific target model
 * 
 * @param {string} prompt - The optimized prompt
 * @param {string} modelId - Target model ID (claude, chatgpt, gemini, deepseek, generic)
 * @returns {string} - Model-adapted prompt
 */
function adaptPrompt(prompt, modelId = 'generic') {
  switch (modelId) {
    case 'claude':
      return adaptForClaude(prompt);
    case 'chatgpt':
      return adaptForChatGPT(prompt);
    case 'gemini':
      return adaptForGemini(prompt);
    case 'deepseek':
      return adaptForDeepSeek(prompt);
    case 'generic':
    default:
      return adaptGeneric(prompt);
  }
}

/**
 * Get all available model profiles for the UI
 */
function getModelProfiles() {
  return Object.values(MODEL_PROFILES);
}

/**
 * Get a specific model profile
 */
function getModelProfile(modelId) {
  return MODEL_PROFILES[modelId] || MODEL_PROFILES.generic;
}


export { adaptPrompt, getModelProfiles, getModelProfile, MODEL_PROFILES };
