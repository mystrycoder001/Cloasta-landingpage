/**
 * Cloasta — Usage Tracker
 * 
 * Manages daily limits for the free version using chrome.storage.local.
 */

const LIMITS = {
  OPTIMIZATIONS: 5,
  SUMMARIES: 3
};

const STORAGE_KEY = 'cloasta_usage_state';

function getDefaultState() {
  return {
    date: new Date().toISOString().split('T')[0], // YYYY-MM-DD
    optimizations: 0,
    summaries: 0
  };
}

async function getUsageState() {
  return new Promise((resolve) => {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.get([STORAGE_KEY], (result) => {
        let state = result[STORAGE_KEY] || getDefaultState();
        
        // Reset if date changed
        const today = new Date().toISOString().split('T')[0];
        if (state.date !== today) {
          state.date = today;
          state.optimizations = 0;
          state.summaries = 0;
          saveUsageState(state);
        }
        
        resolve(state);
      });
    } else {
      // LocalStorage fallback for non-extension environments (dev)
      let state = getDefaultState();
      try {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) {
          state = JSON.parse(stored);
        }
        const today = new Date().toISOString().split('T')[0];
        if (state.date !== today) {
          state.date = today;
          state.optimizations = 0;
          state.summaries = 0;
          localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
        }
      } catch (e) {}
      resolve(state);
    }
  });
}

async function saveUsageState(state) {
  return new Promise((resolve) => {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.set({ [STORAGE_KEY]: state }, resolve);
    } else {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
      } catch (e) {}
      resolve();
    }
  });
}

/**
 * Checks if the user can perform an action based on daily limits.
 * @param {string} actionType - 'optimize' or 'summarize'
 * @returns {Promise<{ allowed: boolean, remaining: number }>}
 */
async function checkLimit(actionType) {
  return { allowed: true, remaining: Infinity };
}

/**
 * Increments the usage counter for an action.
 * @param {string} actionType - 'optimize' or 'summarize'
 */
async function incrementUsage(actionType) {
  const state = await getUsageState();
  
  if (actionType === 'optimize') {
    state.optimizations += 1;
  } else if (actionType === 'summarize') {
    state.summaries += 1;
  }
  
  await saveUsageState(state);
  return state;
}

export { getUsageState, checkLimit, incrementUsage, LIMITS };
