/**
 * Cloasta — Firebase Integration
 * 
 * Handles Firebase Auth and Firestore operations.
 * This module is optional — the extension works fully offline
 * using chrome.storage.local without Firebase.
 * 
 * Firebase adds:
 * - Google Sign-In authentication
 * - Cloud sync of AI Passport across devices
 * - Prompt history stored in Firestore
 * 
 * ⚠️ Replace the config in firebase/firebaseConfig.js with your
 *    actual Firebase project credentials before using.
 */

import firebaseConfig from '../firebase/firebaseConfig.js';

let firebaseApp = null;
let auth = null;
let db = null;
let currentUser = null;
let isInitialized = false;

/* ══════════════════════════════════════════════
   INITIALIZATION
   ══════════════════════════════════════════════ */

/**
 * Initialize Firebase (lazy — only when needed)
 * Uses Firebase CDN modules for Chrome Extension compatibility
 */
async function initFirebase() {
  if (isInitialized) return { auth, db };

  // Check if config has been set
  if (!firebaseConfig.apiKey || firebaseConfig.apiKey === 'YOUR_API_KEY') {
    console.log('Firebase not configured. Running in offline mode.');
    return null;
  }

  try {
    // Dynamic import of Firebase modules from CDN
    // In production, bundle these or use importmap
    const { initializeApp } = await import(
      /* webpackIgnore: true */
      'https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js'
    );
    const { getAuth, onAuthStateChanged, signInWithCredential, GoogleAuthProvider, signOut: fbSignOut } = await import(
      /* webpackIgnore: true */
      'https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js'
    );
    const { getFirestore, doc, getDoc, setDoc, collection, addDoc, query, orderBy, limit, getDocs } = await import(
      /* webpackIgnore: true */
      'https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js'
    );

    firebaseApp = initializeApp(firebaseConfig);
    auth = getAuth(firebaseApp);
    db = getFirestore(firebaseApp);
    isInitialized = true;

    // Listen for auth state changes
    onAuthStateChanged(auth, (user) => {
      currentUser = user;
      if (user) {
        console.log('Cloasta: Signed in as', user.email);
      } else {
        console.log('Cloasta: Signed out');
      }
    });

    console.log('Firebase initialized successfully');
    return { auth, db };
  } catch (error) {
    console.error('Firebase initialization error:', error);
    return null;
  }
}


/* ══════════════════════════════════════════════
   AUTHENTICATION
   ══════════════════════════════════════════════ */

/**
 * Sign in with Google using chrome.identity API
 * This gets a Google OAuth token and exchanges it for Firebase auth
 */
async function signInWithGoogle() {
  const firebase = await initFirebase();
  if (!firebase) {
    throw new Error('Firebase not configured');
  }

  return new Promise((resolve, reject) => {
    // Use chrome.identity to get Google OAuth token
    chrome.identity.getAuthToken({ interactive: true }, async (token) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }

      try {
        const { GoogleAuthProvider, signInWithCredential } = await import(
          /* webpackIgnore: true */
          'https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js'
        );

        const credential = GoogleAuthProvider.credential(null, token);
        const userCredential = await signInWithCredential(auth, credential);
        currentUser = userCredential.user;
        resolve(currentUser);
      } catch (error) {
        reject(error);
      }
    });
  });
}

/**
 * Sign out
 */
async function signOut() {
  const firebase = await initFirebase();
  if (!firebase) return;

  try {
    const { signOut: fbSignOut } = await import(
      /* webpackIgnore: true */
      'https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js'
    );
    await fbSignOut(auth);
    currentUser = null;

    // Also revoke the chrome.identity token
    chrome.identity.getAuthToken({ interactive: false }, (token) => {
      if (token) {
        chrome.identity.removeCachedAuthToken({ token });
      }
    });
  } catch (error) {
    console.error('Sign out error:', error);
  }
}

/**
 * Get current user
 */
function getCurrentUser() {
  return currentUser;
}

/**
 * Check if user is authenticated
 */
function isAuthenticated() {
  return !!currentUser;
}


/* ══════════════════════════════════════════════
   FIRESTORE — AI PASSPORT SYNC
   ══════════════════════════════════════════════ */

/**
 * Sync passport to Firestore
 */
async function syncPassportToCloud(passport) {
  const firebase = await initFirebase();
  if (!firebase || !currentUser) return;

  try {
    const { doc, setDoc } = await import(
      /* webpackIgnore: true */
      'https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js'
    );

    await setDoc(doc(db, 'users', currentUser.uid, 'data', 'passport'), {
      ...passport,
      syncedAt: new Date().toISOString()
    });

    console.log('Passport synced to cloud');
  } catch (error) {
    console.error('Passport sync error:', error);
  }
}

/**
 * Load passport from Firestore
 */
async function loadPassportFromCloud() {
  const firebase = await initFirebase();
  if (!firebase || !currentUser) return null;

  try {
    const { doc, getDoc } = await import(
      /* webpackIgnore: true */
      'https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js'
    );

    const docSnap = await getDoc(doc(db, 'users', currentUser.uid, 'data', 'passport'));
    if (docSnap.exists()) {
      return docSnap.data();
    }
    return null;
  } catch (error) {
    console.error('Load passport from cloud error:', error);
    return null;
  }
}


/* ══════════════════════════════════════════════
   FIRESTORE — PROMPT HISTORY
   ══════════════════════════════════════════════ */

/**
 * Save a prompt to history
 */
async function savePromptToHistory(promptData) {
  const firebase = await initFirebase();
  if (!firebase || !currentUser) return;

  try {
    const { collection, addDoc } = await import(
      /* webpackIgnore: true */
      'https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js'
    );

    await addDoc(collection(db, 'users', currentUser.uid, 'history'), {
      ...promptData,
      createdAt: new Date().toISOString()
    });
  } catch (error) {
    console.error('Save history error:', error);
  }
}

/**
 * Load prompt history (most recent first)
 */
async function loadPromptHistory(count = 20) {
  const firebase = await initFirebase();
  if (!firebase || !currentUser) return [];

  try {
    const { collection, query, orderBy, limit, getDocs } = await import(
      /* webpackIgnore: true */
      'https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js'
    );

    const q = query(
      collection(db, 'users', currentUser.uid, 'history'),
      orderBy('createdAt', 'desc'),
      limit(count)
    );

    const snapshot = await getDocs(q);
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
  } catch (error) {
    console.error('Load history error:', error);
    return [];
  }
}


export {
  initFirebase,
  signInWithGoogle,
  signOut,
  getCurrentUser,
  isAuthenticated,
  syncPassportToCloud,
  loadPassportFromCloud,
  savePromptToHistory,
  loadPromptHistory
};
