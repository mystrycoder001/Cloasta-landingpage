/**
 * Cloasta — Background Service Worker
 * 
 * Manages the extension lifecycle:
 * - Side panel open/close
 * - Context menu integration
 * - Message passing between content scripts and side panel
 */

/* ══════════════════════════════════════════════
   SIDE PANEL SETUP
   ══════════════════════════════════════════════ */

// Open side panel when extension icon is clicked
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true })
  .catch((error) => console.error('Error setting panel behavior:', error));


/* ══════════════════════════════════════════════
   CONTEXT MENU
   ══════════════════════════════════════════════ */

// Create context menu items on install
chrome.runtime.onInstalled.addListener(() => {
  // "Optimize with Cloasta" on text selection
  chrome.contextMenus.create({
    id: 'cloasta-optimize',
    title: 'Optimize with Cloasta',
    contexts: ['selection']
  });

  // "Summarize with Cloasta" on text selection
  chrome.contextMenus.create({
    id: 'cloasta-summarize',
    title: 'Summarize with Cloasta',
    contexts: ['selection']
  });

  console.log('Cloasta extension installed. Context menus created.');
});

// Handle context menu clicks
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (!info.selectionText) return;

  const action = info.menuItemId === 'cloasta-optimize' ? 'optimize' : 'summarize';

  // Open side panel first
  chrome.sidePanel.open({ tabId: tab.id }).then(() => {
    // Send the selected text to the side panel after a brief delay
    // to ensure the panel is loaded
    setTimeout(() => {
      chrome.runtime.sendMessage({
        type: 'CLOASTA_CONTEXT_MENU',
        action: action,
        text: info.selectionText
      });
    }, 500);
  }).catch(err => {
    console.error('Error opening side panel:', err);
  });
});


/* ══════════════════════════════════════════════
   MESSAGE HANDLING & RELIABLE SYNC DELIVERY
   ══════════════════════════════════════════════ */

let pendingSyncData = null;
let activeSyncTimeout = null;

/**
 * Attempts to deliver conversation data directly to the side panel.
 * Uses an incremental backoff sequence (300ms, 800ms, 1500ms, 2500ms) until the panel
 * acknowledges receipt with `{ status: 'ok' }`.
 */
function deliverToPanel(text, platform) {
  const backoffs = [300, 800, 1500, 2500];
  let attempt = 0;

  // Clear any existing active retry loops to prevent duplicate overlapping loops
  if (activeSyncTimeout) {
    clearTimeout(activeSyncTimeout);
    activeSyncTimeout = null;
  }

  function attemptDelivery() {
    if (!chrome?.runtime?.id) return;

    chrome.runtime.sendMessage(
      { type: 'CLOASTA_CONVERSATION_DATA', text, platform },
      (response) => {
        if (chrome.runtime.lastError) {
          console.log(`[Service Worker] Panel delivery attempt ${attempt + 1} failed. Sidepanel might still be loading...`);
        } else if (response && response.status === 'ok') {
          console.log('[Service Worker] Direct panel delivery successful! Clearing pending cache.');
          pendingSyncData = null; // Clean cache on successful receipt
          return;
        }

        if (attempt < backoffs.length) {
          const delay = backoffs[attempt];
          attempt++;
          console.log(`[Service Worker] Retrying direct panel sync in ${delay}ms (attempt ${attempt})...`);
          activeSyncTimeout = setTimeout(attemptDelivery, delay);
        } else {
          console.warn('[Service Worker] All delivery retries failed. Panel must rely on pre-flight storage verification.');
        }
      }
    );
  }

  attemptDelivery();
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.type) {
    case 'CLOASTA_GET_PAGE_INFO':
      // Content script requesting info
      sendResponse({ status: 'ok' });
      break;

    case 'CLOASTA_EXTRACT_CONVERSATION':
      // Forward conversation extraction request to content script
      if (message.tabId) {
        chrome.tabs.sendMessage(message.tabId, {
          type: 'EXTRACT_CONVERSATION'
        }, (response) => {
          sendResponse(response);
        });
        return true; // Keep sendResponse channel open
      }
      break;

    case 'CLOASTA_OPEN_PANEL':
      // Open side panel from content script
      if (sender.tab) {
        chrome.sidePanel.open({ tabId: sender.tab.id });
      }
      sendResponse({ status: 'ok' });
      break;

    case 'CLOASTA_CONVERSATION_DATA':
      // Cache the sync data and trigger delivery retries
      console.log(`[Service Worker] Received sync data from ${message.platform}. Initiating deliverToPanel retry loop...`);
      pendingSyncData = {
        text: message.text,
        platform: message.platform,
        timestamp: Date.now()
      };
      deliverToPanel(message.text, message.platform);
      sendResponse({ status: 'ok' });
      break;

    case 'CLOASTA_PANEL_READY':
      // Handshake: Side panel is initialized and ready
      console.log('[Service Worker] Handshake received: Side Panel is ready.');
      if (pendingSyncData && (Date.now() - pendingSyncData.timestamp < 60000)) {
        console.log('[Service Worker] Instantly delivering cached sync data on panel ready...');
        deliverToPanel(pendingSyncData.text, pendingSyncData.platform);
      }
      sendResponse({ status: 'ok' });
      break;

    default:
      break;
  }
});


/* ══════════════════════════════════════════════
   TAB CHANGE LISTENER
   ══════════════════════════════════════════════ */

// Track when user switches to a supported AI chat tab
chrome.tabs.onActivated.addListener(async (activeInfo) => {
  try {
    const tab = await chrome.tabs.get(activeInfo.tabId);
    if (tab.url && isAIChatUrl(tab.url)) {
      // Optionally: update the extension badge to indicate Cloasta is available
      chrome.action.setBadgeText({ text: '✦', tabId: activeInfo.tabId });
      chrome.action.setBadgeBackgroundColor({ color: '#7c3aed', tabId: activeInfo.tabId });
    } else {
      chrome.action.setBadgeText({ text: '', tabId: activeInfo.tabId });
    }
  } catch (e) {
    // Tab might not exist yet
  }
});

// Also check on URL changes
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.url) {
    if (isAIChatUrl(changeInfo.url)) {
      chrome.action.setBadgeText({ text: '✦', tabId });
      chrome.action.setBadgeBackgroundColor({ color: '#7c3aed', tabId });
    } else {
      chrome.action.setBadgeText({ text: '', tabId });
    }
  }
});


/* ══════════════════════════════════════════════
   HELPERS
   ══════════════════════════════════════════════ */

/**
 * Check if a URL is a supported AI chat platform
 */
function isAIChatUrl(url) {
  const aiDomains = [
    'chat.openai.com',
    'chatgpt.com',
    'claude.ai',
    'gemini.google.com',
    'chat.deepseek.com',
    'copilot.microsoft.com'
  ];

  try {
    const urlObj = new URL(url);
    return aiDomains.some(domain => urlObj.hostname.includes(domain));
  } catch {
    return false;
  }
}
