/**
 * Cloasta — Content Script Detector
 * 
 * Injected into supported AI chat platforms to:
 * 1. Inject a floating Cloasta badge.
 * 2. Extract conversation text when requested or when badge is clicked.
 * 3. Communicate with the background script and side panel.
 */

(function () {
  'use strict';

  // 1. Configuration & Constants
  const SUPPORTED_PLATFORMS = [
    'chatgpt.com',
    'chat.openai.com',
    'claude.ai',
    'gemini.google.com',
    'chat.deepseek.com',
    'copilot.microsoft.com'
  ];

  const BADGE_ID = 'cloasta-floating-badge';

  // Centralized CSS Selectors for precise message extraction
  const PLATFORM_SELECTORS = {
    'chatgpt.com': [
      '[data-testid^="conversation-turn"]',
      '.react-scroll-to-bottom--css article',
      '.group.w-full'
    ],
    'openai.com': [
      '[data-testid^="conversation-turn"]',
      '.react-scroll-to-bottom--css article',
      '.group.w-full'
    ],
    'claude.ai': [
      '.font-user-message',
      '.font-claude-message',
      '[data-testid="message"]',
      '.message-bubble-style'
    ],
    'gemini.google.com': [
      'message-content',
      '.query-text',
      '.model-response-text',
      '.conversation-container'
    ],
    'deepseek.com': [
      '.ds-chat-message',
      '.ds-markdown',
      '.ds-chat-message-wrapper'
    ],
    'copilot.microsoft.com': [
      'cib-chat-turn',
      'cib-message',
      '.ac-textBlock',
      '.message-content'
    ]
  };

  // 2. Initialization
  function init() {
    // Check if we are on a supported platform
    const hostname = window.location.hostname;
    const isSupported = SUPPORTED_PLATFORMS.some(domain => hostname.includes(domain));
    
    if (!isSupported) return;

    // Avoid duplicate injections
    if (document.getElementById(BADGE_ID)) return;

    injectBadge();
    setupMessageListeners();
  }

  // 3. UI Injection
  function injectBadge() {
    // Inject pulse animation keyframes
    const styleSheet = document.createElement('style');
    styleSheet.textContent = `
      @keyframes cloasta-pulse {
        0% { box-shadow: 0 4px 12px rgba(124, 58, 237, 0.4), 0 0 0 0 rgba(124, 58, 237, 0.3); }
        70% { box-shadow: 0 4px 12px rgba(124, 58, 237, 0.4), 0 0 0 10px rgba(124, 58, 237, 0); }
        100% { box-shadow: 0 4px 12px rgba(124, 58, 237, 0.4), 0 0 0 0 rgba(124, 58, 237, 0); }
      }
    `;
    document.head.appendChild(styleSheet);

    const badge = document.createElement('div');
    badge.id = BADGE_ID;
    
    // Inline styles — premium gradient badge
    Object.assign(badge.style, {
      position: 'fixed',
      bottom: '24px',
      right: '24px',
      width: '48px',
      height: '48px',
      background: 'linear-gradient(135deg, #7c3aed 0%, #06b6d4 100%)',
      color: '#ffffff',
      borderRadius: '50%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      boxShadow: '0 4px 12px rgba(124, 58, 237, 0.4)',
      cursor: 'pointer',
      zIndex: '2147483647',
      transition: 'transform 0.2s ease, box-shadow 0.2s ease',
      fontSize: '24px',
      userSelect: 'none',
      fontFamily: 'system-ui, -apple-system, sans-serif',
      animation: 'cloasta-pulse 2s infinite'
    });

    badge.innerText = '✨'; // Cloasta Premium Spark icon
    badge.title = 'Sync with Cloasta Pro';

    // Hover effects
    badge.addEventListener('mouseenter', () => {
      badge.style.transform = 'scale(1.1)';
      badge.style.boxShadow = '0 6px 20px rgba(124, 58, 237, 0.5), 0 0 30px rgba(6, 182, 212, 0.3)';
      badge.style.animation = 'none';
    });
    badge.addEventListener('mouseleave', () => {
      badge.style.transform = 'scale(1)';
      badge.style.boxShadow = '0 4px 12px rgba(124, 58, 237, 0.4)';
      badge.style.animation = 'cloasta-pulse 2s infinite';
    });

    // Click handler
    badge.addEventListener('click', handleBadgeClick);

    document.body.appendChild(badge);
  }

  // 4. Interaction Handlers
  function handleBadgeClick() {
    try {
      if (!chrome?.runtime?.id) {
        console.warn("Cloasta runtime invalidated.");
        return;
      }

      const conversationText = extractConversation();
      const platform = getPlatformName();

      // 1. Buffer sync data locally in storage
      const syncData = {
        text: conversationText,
        platform: platform,
        timestamp: Date.now()
      };

      chrome.storage.local.set({ 'cloasta_pending_sync': syncData }, () => {
        if (chrome.runtime.lastError) {
          console.warn("Storage write failed:", chrome.runtime.lastError.message);
        } else {
          console.log("[Content Script] Cached conversation successfully under cloasta_pending_sync");
        }

        // 2. Request the background worker to open the side panel
        chrome.runtime.sendMessage({ type: "CLOASTA_OPEN_PANEL" }, () => {
          if (chrome.runtime.lastError) {
            console.warn("Runtime open panel message failed:", chrome.runtime.lastError.message);
          }

          // 3. Attempt direct message delivery with retry mechanism
          attemptDirectDelivery(conversationText, platform);
        });
      });

    } catch (err) {
      console.warn("Badge click failed:", err);
    }
  }

  /**
   * Attempts to directly deliver the conversation data to the extension runtime,
   * retrying a few times if the receiving end (sidepanel) is still booting.
   */
  function attemptDirectDelivery(text, platform) {
    let attempts = 0;
    const maxAttempts = 4;
    const delay = 500;

    function send() {
      if (!chrome?.runtime?.id) return;

      chrome.runtime.sendMessage(
        { type: "CLOASTA_CONVERSATION_DATA", text, platform },
        (response) => {
          if (chrome.runtime.lastError) {
            console.log(`[Content Script] Direct sync attempt ${attempts + 1} failed (sidepanel opening). Retrying...`);
          } else if (response && response.status === 'ok') {
            console.log("[Content Script] Direct delivery acknowledged by sidepanel!");
            return;
          }

          if (attempts < maxAttempts) {
            attempts++;
            setTimeout(send, delay);
          }
        }
      );
    }

    send();
  }

  // 5. Message Listeners
  function setupMessageListeners() {
    try {
      if (!chrome?.runtime?.id) return;
      
      chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (message.type === 'EXTRACT_CONVERSATION') {
          const text = extractConversation();
          sendResponse({ status: 'ok', text: text, platform: getPlatformName() });
        }
        return true; // Keep channel open for async response
      });
    } catch (err) {
      console.warn("Setup message listeners failed:", err);
    }
  }

  // 6. Extraction Logic (Clean & Domain-Tailored)
  function extractConversation() {
    try {
      const hostname = window.location.hostname;
      
      // Determine the matching platform selectors
      let matchedPlatform = null;
      for (const platform of Object.keys(PLATFORM_SELECTORS)) {
        if (hostname.includes(platform)) {
          matchedPlatform = platform;
          break;
        }
      }

      if (matchedPlatform) {
        const selectors = PLATFORM_SELECTORS[matchedPlatform];
        let elements = [];
        
        // Try precise selectors in order of specificity
        for (const selector of selectors) {
          const found = document.querySelectorAll(selector);
          if (found && found.length > 0) {
            elements = Array.from(found);
            break;
          }
        }

        if (elements.length > 0) {
          const texts = elements.map(el => {
            const txt = el.innerText ? el.innerText.trim() : '';
            return txt;
          }).filter(txt => txt.length > 0);

          if (texts.length > 0) {
            return cleanText(texts.join('\n\n'));
          }
        }
      }

      // Fallback 1: Try common chat wrapper containers
      const containers = [
        document.querySelector('main'),
        document.querySelector('[class*="react-scroll-to-bottom"]'),
        document.querySelector('.ds-chat-message'),
        document.querySelector('message-content'),
        document.querySelector('#chat-history'),
        document.querySelector('.chat-history')
      ];

      const mainContainer = containers.find(c => c !== null);
      if (mainContainer) {
        return cleanText(mainContainer.innerText);
      }

      // Fallback 2: Absolute fallback - scrape entire body text
      console.warn('Cloasta: No specific selectors or main container matched. Scrapes full body.');
      return cleanText(document.body.innerText);

    } catch (e) {
      console.error('Cloasta: Failed to extract conversation', e);
      return '';
    }
  }

  // 7. Utilities
  function cleanText(text) {
    if (!text) return '';
    return text
      .replace(/\n{3,}/g, '\n\n') // Collapse excessive newlines
      .trim();
  }

  function getPlatformName() {
    const hostname = window.location.hostname;
    if (hostname.includes('chatgpt.com') || hostname.includes('openai.com')) return 'ChatGPT';
    if (hostname.includes('claude.ai')) return 'Claude';
    if (hostname.includes('gemini.google.com')) return 'Gemini';
    if (hostname.includes('deepseek.com')) return 'DeepSeek';
    if (hostname.includes('copilot.microsoft.com')) return 'Copilot';
    return 'AI Chat';
  }

  // Run initialization
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
