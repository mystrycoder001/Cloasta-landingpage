/**
 * Cloasta — Auth MVP
 * 
 * Uses chrome.identity to handle Google Sign-in. 
 * Lightweight integration for MVP without full backend overhead.
 */

const AUTH_STATE_KEY = 'cloasta_auth_state';

async function getAuthState() {
  return new Promise((resolve) => {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.get([AUTH_STATE_KEY], (result) => {
        resolve(result[AUTH_STATE_KEY] || { isAuthenticated: false, user: null });
      });
    } else {
      resolve({ isAuthenticated: false, user: null });
    }
  });
}

async function saveAuthState(state) {
  return new Promise((resolve) => {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.set({ [AUTH_STATE_KEY]: state }, resolve);
    } else {
      resolve();
    }
  });
}

/**
 * Triggers Chrome's native OAuth2 flow for Google Sign-In.
 */
async function signIn() {
  return new Promise((resolve, reject) => {
    if (typeof chrome === 'undefined' || !chrome.identity) {
      return reject(new Error('chrome.identity API not available (Requires Chrome Extension context)'));
    }

    // Pass interactive: true to prompt the user if they haven't authorized yet
    chrome.identity.getAuthToken({ interactive: true }, async (token) => {
      if (chrome.runtime.lastError) {
        return reject(new Error(chrome.runtime.lastError.message));
      }

      try {
        // Fetch basic profile info from Google API using the token
        const response = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        
        if (!response.ok) throw new Error('Failed to fetch user info');
        
        const userInfo = await response.json();
        
        const state = {
          isAuthenticated: true,
          user: {
            email: userInfo.email,
            name: userInfo.name,
            picture: userInfo.picture
          }
        };
        
        await saveAuthState(state);
        resolve(state);
      } catch (err) {
        reject(err);
      }
    });
  });
}

async function signOut() {
  return new Promise(async (resolve) => {
    if (typeof chrome !== 'undefined' && chrome.identity) {
      chrome.identity.getAuthToken({ interactive: false }, (token) => {
        if (token) {
          // Remove cached token
          chrome.identity.removeCachedAuthToken({ token }, async () => {
            await saveAuthState({ isAuthenticated: false, user: null });
            resolve();
          });
        } else {
          saveAuthState({ isAuthenticated: false, user: null }).then(resolve);
        }
      });
    } else {
      await saveAuthState({ isAuthenticated: false, user: null });
      resolve();
    }
  });
}

export { getAuthState, signIn, signOut };
