/**
 * Cloasta — Content Script Detector
 * 
 * Injected into supported AI chat platforms to:
 * 1. Inject a floating Cloasta badge.
 * 2. Extract conversation text when requested or when badge is clicked.
 * 3. Communicate with the background script and side panel.
 * 
 * Uses chrome.storage.local as a reliable message bus so conversation data
 * is never lost due to panel-loading race conditions.
 */

(function () {
  'use strict';

  // 1. Configuration & Constants
  const SUPPORTED_PLATFORMS = [
    'chatgpt.com',
    'chat.openai.com',
    'claude.ai',
    'gemini.google.com',
    'chat.deepseek.com',
    'copilot.microsoft.com'
  ];

  const BADGE_ID = 'cloasta-floating-badge';
  const STORAGE_KEY = 'cloasta_pending_sync';

  // 2. Initialization
  function init() {
    const hostname = window.location.hostname;
    const isSupported = SUPPORTED_PLATFORMS.some(domain => hostname.includes(domain));
    
    if (!isSupported) return;

    // Avoid duplicate injections
    if (document.getElementById(BADGE_ID)) return;

    injectBadge();
    setupMessageListeners();
  }

  // 3. Runtime health check — detects context invalidation
  function isRuntimeValid() {
    try {
      return !!(chrome && chrome.runtime && chrome.runtime.id);
    } catch (e) {
      return false;
    }
  }

  // 4. UI Injection
  function injectBadge() {
    // Inject pulse animation keyframes
    const styleSheet = document.createElement('style');
    styleSheet.textContent = `
      @keyframes cloasta-pulse {
        0% { box-shadow: 0 4px 12px rgba(124, 58, 237, 0.4), 0 0 0 0 rgba(124, 58, 237, 0.3); }
        70% { box-shadow: 0 4px 12px rgba(124, 58, 237, 0.4), 0 0 0 10px rgba(124, 58, 237, 0); }
        100% { box-shadow: 0 4px 12px rgba(124, 58, 237, 0.4), 0 0 0 0 rgba(124, 58, 237, 0); }
      }
      @keyframes cloasta-capture {
        0% { transform: scale(1); }
        30% { transform: scale(0.85); }
        60% { transform: scale(1.15); }
        100% { transform: scale(1); }
      }
      #${BADGE_ID}.cloasta-capturing {
        animation: cloasta-capture 0.5s ease !important;
        background: linear-gradient(135deg, #22c55e 0%, #06b6d4 100%) !important;
      }
    `;
    document.head.appendChild(styleSheet);

    const badge = document.createElement('div');
    badge.id = BADGE_ID;
    
    // Inline styles — premium gradient badge
    Object.assign(badge.style, {
      position: 'fixed',
      bottom: '24px',
      right: '24px',
      width: '48px',
      height: '48px',
      background: 'linear-gradient(135deg, #7c3aed 0%, #06b6d4 100%)',
      color: '#ffffff',
      borderRadius: '50%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      boxShadow: '0 4px 12px rgba(124, 58, 237, 0.4)',
      cursor: 'pointer',
      zIndex: '2147483647',
      transition: 'transform 0.2s ease, box-shadow 0.2s ease',
      fontSize: '24px',
      userSelect: 'none',
      fontFamily: 'system-ui, -apple-system, sans-serif',
      animation: 'cloasta-pulse 2s infinite'
    });

    badge.innerText = '✦'; // Cloasta icon
    badge.title = 'Capture & Sync with Cloasta';

    // Hover effects
    badge.addEventListener('mouseenter', () => {
      badge.style.transform = 'scale(1.1)';
      badge.style.boxShadow = '0 6px 20px rgba(124, 58, 237, 0.5), 0 0 30px rgba(6, 182, 212, 0.3)';
      badge.style.animation = 'none';
    });
    badge.addEventListener('mouseleave', () => {
      if (!badge.classList.contains('cloasta-capturing')) {
        badge.style.transform = 'scale(1)';
        badge.style.boxShadow = '0 4px 12px rgba(124, 58, 237, 0.4)';
        badge.style.animation = 'cloasta-pulse 2s infinite';
      }
    });

    // Click handler
    badge.addEventListener('click', handleBadgeClick);

    document.body.appendChild(badge);
  }

  // 5. Interaction Handlers — FIXED: Extract first, store, then open panel
  function handleBadgeClick() {
    const badge = document.getElementById(BADGE_ID);

    // 5a. Check runtime health
    if (!isRuntimeValid()) {
      showPageToast('Cloasta extension was updated. Please refresh this page.');
      return;
    }

    // 5b. Visual feedback — immediate capture animation
    if (badge) {
      badge.classList.add('cloasta-capturing');
      setTimeout(() => {
        badge.classList.remove('cloasta-capturing');
        badge.style.animation = 'cloasta-pulse 2s infinite';
      }, 600);
    }

    // 5c. Extract conversation FIRST (before opening panel)
    const conversationText = extractConversation();
    const platform = detectPlatform();

    if (!conversationText || conversationText.trim().length < 10) {
      showPageToast('No conversation found on this page yet.');
      return;
    }

    // 5d. Store conversation data in chrome.storage.local
    //     This is the RELIABLE message bus — survives panel load timing
    const syncPayload = {
      text: conversationText,
      platform: platform,
      url: window.location.href,
      capturedAt: Date.now()
    };

    try {
      chrome.storage.local.set({ [STORAGE_KEY]: syncPayload }, () => {
        if (chrome.runtime.lastError) {
          console.warn('Cloasta: Storage write failed:', chrome.runtime.lastError.message);
          return;
        }

        // 5e. Open the side panel
        chrome.runtime.sendMessage(
          { type: 'CLOASTA_OPEN_PANEL' },
          () => {
            if (chrome.runtime.lastError) {
              console.warn('Cloasta: Panel open failed:', chrome.runtime.lastError.message);
              return;
            }

            // 5f. Also try direct message delivery (belt-and-suspenders)
            //     Retry a few times with increasing delay for panel load
            deliverConversationData(syncPayload, 0);
          }
        );
      });
    } catch (err) {
      console.warn('Cloasta: Badge click failed:', err);
    }
  }

  /**
   * Attempts to deliver conversation data via runtime message.
   * Retries up to 3 times with increasing delay to handle panel loading.
   */
  function deliverConversationData(payload, attempt) {
    if (attempt >= 4 || !isRuntimeValid()) return;

    const delay = [300, 800, 1500, 2500][attempt];

    setTimeout(() => {
      try {
        if (!isRuntimeValid()) return;

        chrome.runtime.sendMessage({
          type: 'CLOASTA_CONVERSATION_DATA',
          text: payload.text,
          platform: payload.platform,
          url: payload.url,
          capturedAt: payload.capturedAt
        }, (response) => {
          if (chrome.runtime.lastError) {
            // Panel not ready yet — retry
            deliverConversationData(payload, attempt + 1);
            return;
          }
          if (response && response.status === 'ok') {
            // Delivered! Clear storage fallback
            chrome.storage.local.remove(STORAGE_KEY);
          } else {
            // No acknowledgment — retry
            deliverConversationData(payload, attempt + 1);
          }
        });
      } catch (err) {
        // Runtime died — stop retrying
      }
    }, delay);
  }

  // 6. Message Listeners
  function setupMessageListeners() {
    try {
      if (!isRuntimeValid()) return;
      
      chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (message.type === 'EXTRACT_CONVERSATION') {
          const text = extractConversation();
          const platform = detectPlatform();
          sendResponse({ status: 'ok', text: text, platform: platform });
        }
        return true; // Keep channel open for async response if needed
      });
    } catch (err) {
      console.warn('Cloasta: Setup message listeners failed:', err);
    }
  }

  // 7. Platform Detection
  function detectPlatform() {
    const hostname = window.location.hostname;
    if (hostname.includes('chatgpt.com') || hostname.includes('chat.openai.com')) return 'chatgpt';
    if (hostname.includes('claude.ai')) return 'claude';
    if (hostname.includes('gemini.google.com')) return 'gemini';
    if (hostname.includes('chat.deepseek.com')) return 'deepseek';
    if (hostname.includes('copilot.microsoft.com')) return 'copilot';
    return 'unknown';
  }

  // 8. Extraction Logic — Platform-specific selectors with resilient fallbacks
  function extractConversation() {
    try {
      const platform = detectPlatform();
      let container = null;

      // Platform-specific selectors (ordered by specificity)
      const platformSelectors = {
        chatgpt: [
          '[role="presentation"]',                              // ChatGPT main thread
          'main div[class*="react-scroll-to-bottom"]',          // Older ChatGPT
          'main'
        ],
        claude: [
          '[class*="conversation-content"]',                    // Claude conversation area
          'main [class*="Thread"]',                             // Claude thread container
          'main'
        ],
        gemini: [
          'main .conversation-container',                       // Gemini conversation
          'message-content',                                    // Gemini message elements
          'main'
        ],
        deepseek: [
          '.ds-chat-message',                                   // DeepSeek chat messages
          '#chat-container',                                    // DeepSeek container
          'main'
        ],
        copilot: [
          '[class*="conversation"]',                             // Copilot conversation area
          'cib-serp',                                           // Copilot shadow DOM entry
          'main'
        ]
      };

      // Try platform-specific selectors first
      const selectors = platformSelectors[platform] || [];
      for (const selector of selectors) {
        try {
          container = document.querySelector(selector);
          if (container && container.innerText && container.innerText.trim().length > 20) {
            break;
          }
          container = null;
        } catch (e) {
          // Invalid selector, skip
          continue;
        }
      }

      // Universal fallbacks
      if (!container) {
        const fallbacks = [
          document.querySelector('main'),
          document.querySelector('[role="main"]'),
          document.querySelector('article')
        ];
        container = fallbacks.find(c => c !== null && c.innerText && c.innerText.trim().length > 20);
      }

      if (container) {
        return cleanText(container.innerText);
      }

      // Absolute fallback: body text (strip obvious noise)
      console.warn('Cloasta: No main chat container found, falling back to body text.');
      return cleanText(document.body.innerText);

    } catch (e) {
      console.error('Cloasta: Failed to extract conversation', e);
      return '';
    }
  }

  // 9. Utility
  function cleanText(text) {
    if (!text) return '';
    return text
      .replace(/\n{3,}/g, '\n\n')  // Collapse excessive newlines
      .replace(/\t+/g, ' ')         // Tabs to spaces
      .trim();
  }

  /**
   * Shows a transient toast on the AI chat page itself (not in the side panel).
   */
  function showPageToast(message) {
    const existingToast = document.getElementById('cloasta-page-toast');
    if (existingToast) existingToast.remove();

    const toast = document.createElement('div');
    toast.id = 'cloasta-page-toast';
    Object.assign(toast.style, {
      position: 'fixed',
      bottom: '82px',
      right: '16px',
      background: 'rgba(15, 15, 20, 0.92)',
      color: '#fff',
      padding: '10px 18px',
      borderRadius: '10px',
      fontSize: '13px',
      fontFamily: 'system-ui, -apple-system, sans-serif',
      zIndex: '2147483647',
      boxShadow: '0 4px 16px rgba(0,0,0,0.4)',
      border: '1px solid rgba(124, 58, 237, 0.3)',
      opacity: '0',
      transform: 'translateY(8px)',
      transition: 'opacity 0.25s ease, transform 0.25s ease',
      maxWidth: '280px',
      lineHeight: '1.4'
    });
    toast.textContent = message;
    document.body.appendChild(toast);

    // Animate in
    requestAnimationFrame(() => {
      toast.style.opacity = '1';
      toast.style.transform = 'translateY(0)';
    });

    // Auto-dismiss
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(8px)';
      setTimeout(() => toast.remove(), 300);
    }, 3000);
  }

  // Run initialization
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
