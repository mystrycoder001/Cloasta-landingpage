/**
 * Cloasta — Background Service Worker
 * 
 * Manages the extension lifecycle:
 * - Side panel open/close
 * - Context menu integration
 * - Message passing between content scripts and side panel
 * - Storage-based conversation sync for reliability
 */

/* ══════════════════════════════════════════════
   SIDE PANEL SETUP
   ══════════════════════════════════════════════ */

// Open side panel when extension icon is clicked
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true })
  .catch((error) => console.error('Error setting panel behavior:', error));


/* ══════════════════════════════════════════════
   CONTEXT MENU
   ══════════════════════════════════════════════ */

// Create context menu items on install
chrome.runtime.onInstalled.addListener(() => {
  // "Optimize with Cloasta" on text selection
  chrome.contextMenus.create({
    id: 'cloasta-optimize',
    title: 'Optimize with Cloasta',
    contexts: ['selection']
  });

  // "Summarize with Cloasta" on text selection
  chrome.contextMenus.create({
    id: 'cloasta-summarize',
    title: 'Summarize with Cloasta',
    contexts: ['selection']
  });

  console.log('Cloasta extension installed. Context menus created.');
});

// Handle context menu clicks
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (!info.selectionText) return;

  const action = info.menuItemId === 'cloasta-optimize' ? 'optimize' : 'summarize';

  // Open side panel first
  chrome.sidePanel.open({ tabId: tab.id }).then(() => {
    // Store the context menu data in storage for reliable delivery
    const contextPayload = {
      type: 'context_menu',
      action: action,
      text: info.selectionText,
      capturedAt: Date.now()
    };

    chrome.storage.local.set({ cloasta_pending_context: contextPayload }, () => {
      // Also try direct message delivery with retries
      deliverToPanel({
        type: 'CLOASTA_CONTEXT_MENU',
        action: action,
        text: info.selectionText
      }, 0);
    });
  }).catch(err => {
    console.error('Error opening side panel:', err);
  });
});


/* ══════════════════════════════════════════════
   MESSAGE HANDLING
   ══════════════════════════════════════════════ */

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.type) {
    case 'CLOASTA_GET_PAGE_INFO':
      sendResponse({ status: 'ok' });
      break;

    case 'CLOASTA_EXTRACT_CONVERSATION':
      // Forward conversation extraction request to content script
      if (message.tabId) {
        chrome.tabs.sendMessage(message.tabId, {
          type: 'EXTRACT_CONVERSATION'
        }, (response) => {
          if (chrome.runtime.lastError) {
            sendResponse({ status: 'error', error: chrome.runtime.lastError.message });
            return;
          }
          sendResponse(response);
        });
        return true; // Keep sendResponse channel open for async
      }
      sendResponse({ status: 'error', error: 'No tabId provided' });
      break;

    case 'CLOASTA_OPEN_PANEL':
      // Open side panel from content script badge click
      if (sender.tab) {
        chrome.sidePanel.open({ tabId: sender.tab.id })
          .then(() => {
            sendResponse({ status: 'ok' });
          })
          .catch((err) => {
            console.error('Error opening side panel:', err);
            sendResponse({ status: 'error', error: err.message });
          });
        return true; // Keep channel open — sidePanel.open() is async
      }
      sendResponse({ status: 'ok' });
      break;

    case 'CLOASTA_CONVERSATION_DATA':
      // Content script sent conversation data — the side panel
      // should pick this up. We just acknowledge receipt.
      // The data is also stored in chrome.storage.local by the
      // content script as a fallback.
      sendResponse({ status: 'ok' });
      break;

    case 'CLOASTA_PANEL_READY':
      // Side panel is loaded and ready to receive data.
      // Check if there's pending sync data in storage.
      sendResponse({ status: 'ok' });
      break;

    default:
      break;
  }
});


/* ══════════════════════════════════════════════
   TAB CHANGE LISTENER
   ══════════════════════════════════════════════ */

// Track when user switches to a supported AI chat tab
chrome.tabs.onActivated.addListener(async (activeInfo) => {
  try {
    const tab = await chrome.tabs.get(activeInfo.tabId);
    if (tab.url && isAIChatUrl(tab.url)) {
      chrome.action.setBadgeText({ text: '✦', tabId: activeInfo.tabId });
      chrome.action.setBadgeBackgroundColor({ color: '#7c3aed', tabId: activeInfo.tabId });
    } else {
      chrome.action.setBadgeText({ text: '', tabId: activeInfo.tabId });
    }
  } catch (e) {
    // Tab might not exist yet
  }
});

// Also check on URL changes
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.url) {
    if (isAIChatUrl(changeInfo.url)) {
      chrome.action.setBadgeText({ text: '✦', tabId });
      chrome.action.setBadgeBackgroundColor({ color: '#7c3aed', tabId });
    } else {
      chrome.action.setBadgeText({ text: '', tabId });
    }
  }
});


/* ══════════════════════════════════════════════
   HELPERS
   ══════════════════════════════════════════════ */

/**
 * Check if a URL is a supported AI chat platform
 */
function isAIChatUrl(url) {
  const aiDomains = [
    'chat.openai.com',
    'chatgpt.com',
    'claude.ai',
    'gemini.google.com',
    'chat.deepseek.com',
    'copilot.microsoft.com'
  ];

  try {
    const urlObj = new URL(url);
    return aiDomains.some(domain => urlObj.hostname.includes(domain));
  } catch {
    return false;
  }
}

/**
 * Attempts to deliver a message to the side panel with retries.
 * Falls back to storage if delivery fails.
 */
function deliverToPanel(message, attempt) {
  if (attempt >= 4) return;

  const delay = [300, 800, 1500, 2500][attempt];

  setTimeout(() => {
    try {
      chrome.runtime.sendMessage(message, (response) => {
        if (chrome.runtime.lastError) {
          deliverToPanel(message, attempt + 1);
          return;
        }
        if (response && response.status === 'ok') {
          // Clear the storage fallback
          if (message.type === 'CLOASTA_CONTEXT_MENU') {
            chrome.storage.local.remove('cloasta_pending_context');
          }
        } else {
          deliverToPanel(message, attempt + 1);
        }
      });
    } catch (err) {
      // Extension context issue — stop retrying
    }
  }, delay);
}
